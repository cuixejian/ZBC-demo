package com.pageoject;

import static org.testng.Assert.assertTrue;
import org.openqa.selenium.By;
import org.testng.annotations.Test;

import www.util.BaseTest;

public class FrontLogin extends BaseTest{
	public FrontLogin() {
		System.out.println("FrontLogin�Ĺ��췽��");
	}
	
	String url="http://localhost:83/";
	@Test(priority=1)
	public void loginSuccess() throws InterruptedException {
		this.driver.get(url);
		
		driver.findElement(By.linkText("��¼")).click();
		Thread.sleep(2000);
		driver.findElement(By.id("username")).sendKeys("13800138006");
		driver.findElement(By.id("password")).sendKeys("123456");
		driver.findElement(By.id("verify_code")).sendKeys("aaaa");
		driver.findElement(By.name("sbtbutton")).click();
		Thread.sleep(2000);
		boolean flag = driver.findElement(By.linkText("��ȫ�˳�")).isDisplayed();
		assertTrue(flag);
		assertTrue(flag,"�˳������Ӳ�����message");
		Thread.sleep(2000);
		driver.findElement(By.linkText("��ȫ�˳�")).click();
		Thread.sleep(2000);
	}
	
	@Test(priority=2)
	public void loginSuccess2() throws InterruptedException {
		this.driver.get(url);
		
		driver.findElement(By.linkText("��¼")).click();
		Thread.sleep(3000);
		driver.findElement(By.id("username")).sendKeys("");
		driver.findElement(By.id("password")).sendKeys("123456");
		driver.findElement(By.id("verify_code")).sendKeys("aaaa");
		driver.findElement(By.name("sbtbutton")).click();
		Thread.sleep(2000);
		boolean flag = driver.findElement(By.linkText("��ȫ�˳�")).isDisplayed();
		assertTrue(flag);
		assertTrue(flag,"�˳������Ӳ�����message");
		Thread.sleep(2000);
		driver.findElement(By.linkText("��ȫ�˳�")).click();
		Thread.sleep(2000);
	}
}